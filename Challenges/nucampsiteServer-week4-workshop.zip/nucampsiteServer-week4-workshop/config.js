module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '816344063783883',
        clientSecret: 'd763dcaf05d1fe5d739537c4038336ba'
    }
}